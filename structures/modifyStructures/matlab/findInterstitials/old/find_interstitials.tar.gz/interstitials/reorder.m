clear all;

name = '.xyz';

fid = fopen(name);

sys = textscan(fid,'%d', 1);
sys = sys{1};

comments = textscan(fid, '%f%d%d%d%f%d%d%d%f');

tmp = textscan(fid, '%2c%f%f%f');

tmp_types = tmp{1,1};
len = length(tmp_types);
types = zeros(len,1);

for i = 1:len
    if tmp_types(i,:) == 'Ge'
        types(i,1) = 2;
    elseif tmp_types(i,:) == 'Si'
        types(i,1) = 1;
    end
end

data = zeros(sys,5);

data(:,2) = 1;
data(:,3) = tmp{1,2};
data(:,4) = tmp{1,3};
data(:,5) = tmp{1,4};

%
%Si = find(data(:,2) == 1);
%Ge = find(data(:,2) == 2);
%
%data = [data(Si,:); data(Ge,:)];

XYZ(data, name);




