%{
This functions takes a matrix of Si atomic positions as well as a string name
and writes a .xyz file for VMD visualization.

    INPUTS
        Pos: Is a 3xN matrix where Pos(1:3,i) is the x y and z coordinates
            of the ith atom
        name: Is a string that determines the name of the output file
    OUTPUTS
        This function writes a file Si.name.N.xyz that can be called for
        VMD visuallization
%}
function writeXYZ(Pos,name)
Pos=transpose(Pos)
sys = length(Pos);
fid = fopen(sprintf('Si.Ge.%s.%d.xyz',name,sys),'w');
fprintf(fid,'%d\r\n',sys);
fprintf(fid,'%4.2f\t0\t0\t0\t%4.2f\t0\t0\t0\t%4.2f\r\n',max(Pos(3,:)),max(Pos(4,:))...
    ,max(Pos(5,:)));
for i = 1:sys
    if Pos(2,i)==1
        fprintf(fid,'C\t%4.2f\t%4.2f\t%4.2f\r\n',Pos(3,i),Pos(4,i),Pos(5,i));
    elseif Pos(2,i)==2
        fprintf(fid,'N\t%4.2f\t%4.2f\t%4.2f\r\n',Pos(3,i),Pos(4,i),Pos(5,i));
    end
end
fclose(fid);
end