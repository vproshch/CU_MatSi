middle = length(data)/2;

left = zeros(1024,5);
right = zeros(1024,5);
data_sub = zeros(length(data),5);

lo = (middle - 1024);
hi = (middle + 1024);

left(:,:) = data(lo+1:middle,:);
right(:,:) = data(middle+1:hi,:);
data_sub(1:lo,:) = data(1:lo,:);
data_sub(hi+1:end,:) = data(hi+1:end,:);

rand_left = randperm(1024,100);
rand_right = randperm(1024,100);

for i = 1:100
    
    j = rand_left(1,i);
    left(j,2) = 2;
    
    k = rand_right(1,i);
    right(k,2) = 1;
    
end

data_sub(lo+1:middle,:) = left(:,:);
data_sub(middle+1:hi,:) = right(:,:);

    
    
