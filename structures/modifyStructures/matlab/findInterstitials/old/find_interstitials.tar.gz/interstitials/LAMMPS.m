function LAMMPS(name)
load(strcat(name,'.mat'));

buffer = 0.009
masses = [28.0855; 72.6400];
xlo = min(Pos(:,3))-buffer; xhi = max(Pos(:,3))+buffer;
ylo = min(Pos(:,4))-buffer; yhi = max(Pos(:,4))+buffer;
zlo = min(Pos(:,5))-buffer; zhi = max(Pos(:,5))+buffer;
sys = length(Pos);

%% Build the Header
fid = fopen(sprintf('data.%d.%s',sys,name),'w');
fprintf(fid,'LAMMPS data file\r\n\r\n%d atoms\r\n\r\n%d atom types\r\n\r\n'...
    ,sys,length(masses))
fprintf(fid,'%6.3f %6.3f xlo xhi\r\n%6.3f %6.3f ylo yhi\r\n%6.3f %6.3f zlo zhi\r\n'...
    ,xlo,xhi,ylo,yhi,zlo,zhi)
fprintf(fid,'\r\nMasses\r\n\r\n')
for i = 1:2
    fprintf(fid,'%d %6.4f\r\n',i,masses(i))
end
fprintf(fid,'\r\nAtoms\r\n\r\n')
%% Atoms
for i = 1:sys  
    fprintf(fid,'%d\t%d\t%6.3f\t%6.3f\t%6.3f\r\n',i,Pos(i,2),Pos(i,3),Pos(i,4),Pos(i,5));
end
fclose(fid);
end