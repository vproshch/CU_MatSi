clear all;
load('bulk_40x8x8.mat');
name = '3x2z';

%%% x = unit cells in y direction. z = "" in z direction %%%
%%% N is no. atoms per unit cell %%%
y = 8;
z = 8;
N = y*z*8;

mid = size(data,1)/2;

%%% dx is the no. unit cells to patten in x direction symmetric
% in EACH direction. dz = distance to move si in + or - %%%
dx = 3; % [0,5]
dz = 2 % [-4,4] (-) for more Ge, (+) for more Si
three_D = 0; % 3D = 0 for no, 1 for yes

lx = N*dx;

data_L = data(1:(mid-lx),:);
data_R = data((mid+lx+1):end,:);

left = data((mid-lx+1):mid,:);
right = data((mid+1):(mid+lx),:);

%%%%%%%%% Move upper and lower chunk edges in cross plane direction

[~,left_z] = sort(left(:,5));
left_z = left(left_z,:);

[~,right_z] = sort(right(:,5));
right_z = right(right_z,:);

mid_z = size(left_z,1)/2;
N_z = mid_z/16;

left_z((mid_z+1:end),2) = 2;
right_z(1:mid_z,2) = 1;


%%%%%%%% Move left and right chunk edges in in-plane direction

lz = N_z*abs(dz)*4;

pos = (dz > 0);
neg = (dz < 0);

if pos == 1;
    left_z((mid_z+1):(mid_z+lz),2) = 1;
    right_z((mid_z+1):(mid_z+lz),2) = 1;
end 

if neg == 1;
    left_z((mid_z-lz+1):mid_z,2) = 2;
    right_z((mid_z-lz+1):mid_z,2) = 2;
end 

%%%%%%%% 3D

if three_D == 1
   left_top = left_z((mid_z+1):end,:);
   left_bottom = left_z(1:mid_z,:);
   
   right_top = right_z((mid_z+1):end,:);
   right_bottom = right_z(1:mid_z,:);
   
   [~,left_ty] = sort(left_top(:,4));
   left_ty = left_top(left_ty,:);
   mid_Lty = size(left_ty,1)/2;
   left_ty((mid_Lty+1):end,2) = 1;
   
   [~,left_by] = sort(left_bottom(:,4));
   left_by = left_bottom(left_by,:);
   mid_Lby = size(left_by,1)/2;
   left_by((mid_Lby+1):end,2) = 2;
   
   [~,right_ty] = sort(right_top(:,4));
   right_ty = right_top(right_ty,:);
   mid_Rty = size(right_ty,1)/2;
   right_ty((mid_Rty+1):end,2) = 1;
   
   [~,right_by] = sort(right_bottom(:,4));
   right_by = right_bottom(right_by,:);
   mid_Rby = size(right_by,1)/2;
   right_by((mid_Rby+1):end,2) = 2;
   
   left_z = [left_ty; left_by];
   right_z = [right_ty; right_by];
end


%%%%%%%% Write structure

Pos = [data_L; left_z; right_z; data_R];
[~,Pos_x] = sort(Pos(:,3));
Pos = Pos(Pos_x,:);
XYZ(Pos, name);

save(name, 'Pos');




