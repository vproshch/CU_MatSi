middle = length(data)/2;

left = zeros(1024,5);
right = zeros(1024,5);
data_vac = zeros(length(data),5);

lo = (middle - 1024);
hi = (middle + 1024);

left(:,:) = data(lo+1:middle,:);
right(:,:) = data(middle+1:hi,:);

data_vac(1:lo,:) = data(1:lo,:);
data_vac(hi+1:end,:) = data(hi+1:end,:);

rand_left = randperm(1008,16);
rand_right = randperm(1008,16);

for i = 1:16
    
    j = rand_left(1,i)
    left_id = left(j,1)
    left(j,:) = []
        
    k = rand_right(1,i)
    right_id = left(k,1)
    right(k,:) = []
    
end

len = length(left);

data_vac(lo+1:(lo+32),:) = [];

data_vac(lo+1:lo+len,:) = left(:,:);
data_vac(lo+len+1:lo+2*len,:) = right(:,:);

len1 = length(data_vac);

for m = 1:len1
    
    data_vac(m,1) = m;
    
end

